### First off, thanks for taking the time to contribute!

For the contribution guide [click here](http://laradock.io/contributing/).
