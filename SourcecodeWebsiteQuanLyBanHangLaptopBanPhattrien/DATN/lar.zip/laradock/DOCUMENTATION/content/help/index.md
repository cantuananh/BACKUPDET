---
title: Help & Questions
type: index
weight: 5
---

Join the chat room on [Gitter](https://gitter.im/Laradock/laradock) and get help and support from the community.

You can as well can open an [issue](https://github.com/laradock/laradock/issues) on Github (will be labeled as Question) and discuss it with people on [Gitter](https://gitter.im/Laradock/laradock).
